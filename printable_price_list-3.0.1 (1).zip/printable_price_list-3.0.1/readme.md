# Printable Pricelist for Zen Carts v1.5.7 and Later

This drop-in plugin provides a printable price-list for your Zen Cart store.  Up to 3 separate variations can be customized; see the plugin's readme.html file for additional information.

**Zen Cart Download:**  https://www.zen-cart.com/downloads.php?do=file&id=173

**Zen Cart Support Thread:** https://www.zen-cart.com/showthread.php?49126-Printable-Price-list-support-thread