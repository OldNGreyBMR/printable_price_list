<?php
// -----
// Part of the "Printable Pricelist" plugin by Cindy Merkin (cindy@vinosdefrutastropicales.com)
// Copyright (c) 2015-2021 Vinos de Frutas Tropicales
//
define('BOX_HEADING_PRICELIST', 'View Price Listing');
