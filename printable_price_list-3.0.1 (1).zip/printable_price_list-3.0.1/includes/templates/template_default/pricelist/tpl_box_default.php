<?php
// -----
// Part of the "Printable Price List" plugin for Zen Cart.
//
// removed all makeup, since we don't wan't fancy boxes (languages and currencies) for the pricelist
echo $content;
