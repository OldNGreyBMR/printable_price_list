<?php
// -----
// Part of the Printable Pricelist plugin for Zen Cart.
//
define('BOX_CONFIGURATION_PL', 'Printable Price-list');
define('BOX_CONFIGURATION_PL_1', 'Price-list Profile-1');
define('BOX_CONFIGURATION_PL_2', 'Price-list Profile-2');
define('BOX_CONFIGURATION_PL_3', 'Price-list Profile-3');
