<?php
// -----
// Previously part of the "Printable Price List" plugin; this file can be safely removed.
//
